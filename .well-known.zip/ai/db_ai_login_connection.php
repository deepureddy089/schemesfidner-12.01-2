<?php
$servername = "localhost"; // Database host
$username = "asse6007_admin"; // Database username (or your custom DB username)
$password = "00000000"; // Database password (or your custom DB password)
$dbname = "asse6007_gov_schemes"; // The database name for login functionality

// Create a connection to the admin login database
$conn = new mysqli($servername, $username, $password, $dbname);

